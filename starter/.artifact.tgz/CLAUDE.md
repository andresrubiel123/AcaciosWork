# Horizontes Bot Template (Pro) — instrucciones para Claude Code

Este repo es el **chatbot de soporte con IA de Horizontes IA** (edición Pro):
un worker de Cloudflare (Hono + Vercel AI SDK + D1 + Vectorize + R2) con
panel de administración en `/admin`. El miembro que lo clona probablemente
**no sabe programar** — tú corres todo por él.

## De dónde salió esta carpeta (el CLI Forja) — para no confundirte

Esta carpeta la **descargó el CLI `forjabot`** (`npx forjabot init`) tras validar la
licencia del miembro; NO es un clone de git ni el repo de desarrollo. Tu único trabajo
aquí es **configurar/operar el bot del miembro** con los skills de `skill/` (empezando
por `/configurar-mi-chatbot`). No hay —ni necesitas— herramientas de "publicar"/
"release" del template: los updates llegan por `forjabot update`. Si el miembro dice
"arma mi bot", "conéctalo a WhatsApp", "cámbiale los precios" → usas el skill que toca
y corres los comandos por él. Nada de tocar el pipeline de distribución.

## Si es una instalación nueva

Si NO existe `.bot-state.json` en la raíz, lo primero es instalar. Usa el
asistente: skill `/configurar-mi-chatbot` (vive en `skill/`; si el usuario no
lo tiene instalado, sigue ese archivo directamente). El orden de instalación
es en 4 FASES y **no se negocia**:

1. **TU PLATAFORMA** — provisiona Cloudflare (D1 + Vectorize; **R2 es OPCIONAL**,
   solo para lead magnets — sáltalo si el usuario no lo va a usar, ver
   `docs/opcional-lead-magnets.md`), guarda la API key del cerebro,
   `DASHBOARD_PASSWORD`, y DEPLOYA.
   ⚠️ **Vectorize (y R2 si lo activa) piden una TARJETA en archivo en Cloudflare
   aunque el uso quede en $0 (free tier). AVÍSALE al usuario de una vez** — verá
   "$0 due today", no le van a cobrar; es política de Cloudflare. Así no se asusta.
   ⚠️ **La API key NUNCA se pega en el chat.** Cuando llegue ese paso, dile que TÚ
   corres `wrangler secret put ANTHROPIC_API_KEY` y ÉL la pega en SU terminal
   (campo oculto) — avísale ANTES para que no intente dártela por el chat.
   Tras el deploy, ofrece
   conectar el bot al dashboard personal del miembro en forjabots.com
   (`npx forjabot login` + `npx forjabot pair` — gratis, idempotente y NO
   bloqueante: si falla, el bot sigue igual y se reintenta después). Al
   terminar esta fase el miembro ya abre su panel en
   `https://<worker>.workers.dev/admin` — todo lo que sigue lo va viendo ahí.
2. **TU CHATBOT** — negocio, tareas, idioma y base de conocimiento.
3. **TUS CONEXIONES** — canales uno por uno con el panel abierto en
   `/admin/conexiones`: cada canal conectado se pone VERDE.
4. **PRUEBA FINAL** — mensaje real + Resumen sin badges rojos.

## Reglas del repo

- **Habla en español sencillo (LATAM)**, una pregunta a la vez.
- **Nunca pidas ni recibas tokens/keys por el chat** — siempre `wrangler secret put`
  (el usuario la pega en SU terminal, campo oculto). Avísale de este flujo ANTES de
  llegar al paso de la key, para que no intente dártela en el chat.
- **No toques `member/`** más allá de lo que indican los skills (ahí viven los
  datos del negocio del miembro; se respetan en cada actualización).
- Package manager: **pnpm**. Scripts reales: `pnpm dev`, `pnpm run deploy`,
  `pnpm typecheck`, `pnpm test`, `pnpm db:apply`, `pnpm db:apply:remote`.
- Corre `pnpm test` antes de cualquier deploy si tocaste `src/`.

## Mapa rápido

- `src/index.ts` — webhooks de canales (Telegram, Twilio/WhatsApp, Meta, ManyChat)
- `src/agent.ts` — el Durable Object que piensa y responde (buffer + tools)
- `src/llm/provider.ts` — cerebro: Anthropic / OpenAI / xAI, con overrides BYO
  del dashboard (Config → Modelo de IA)
- `src/admin/` — el panel (`/admin`): Resumen, Conversaciones, Conexiones,
  Config, KB, Mejoras, Costos
- `src/tools/` — searchKb, handoffHuman, pauseBot, captureLead, scheduleAppointment, catalogQuery, composio (genérico vía Composio, Pro)
- `skill/` — asistentes para el miembro (instalación, actualización, auditoría…)

## Otros flujos

- Actualizar un bot ya instalado → skill `/actualizar-mi-bot`.
- Cambiar de giro/nicho → skill `/re-nichar`.
- El miembro quiere cambiar el modelo de IA → no toques código: panel
  `/admin/config` → sección "Modelo de IA" (soporta API key propia y modelos
  de Claude, OpenAI y Grok, con botón de prueba).

## Starter vs Forja+ (tier del bot)

La matriz exacta de qué desbloquea cada plan, qué pasa al activar Forja+ (el
control plane empuja el tier en caliente vía `POST /api/tier`) y el diagnóstico
cuando "algo Pro no funciona": **`skill/references/starter-vs-forja-plus.md`**.

## Comandos del miembro (skills en `skill/`)

Estas skills son los "comandos" con los que el miembro opera su bot día a día. Cuando
pida algo de esto (o escriba `/nombre`), sigue el archivo correspondiente en `skill/`.
Las marcadas **Pro** hacen gate de tier en su PASO 0 (si el bot es `free`, dan upsell a
la comunidad de Horizontes IA y se detienen).

**Operación del bot**
- `/reporte` — informe mensual de valor para el cliente. *(gratis y Pro)*
- `/analiticas` — explica el panel y sus números en lenguaje de negocio; interactivo y consultivo (distinto de `/reporte`, que es el informe formal). Solo lectura. *(gratis y Pro; Vigilante/Insights son Pro)*
- `/human-in-the-loop` — configura los avisos de handoff (Telegram/email/WhatsApp) + cuánto se pausa el bot cuando el dueño toma el control, y explica el flujo de intervención. *(gratis y Pro; el aviso por WhatsApp es Pro)*
- `/exportar` — exporta leads y conversaciones (CSV/JSON), solo lectura. *(gratis y Pro)*
- `/mantenimiento` — afinación mensual: salud + limpieza de la base de conocimiento. *(Pro)*
- `/afinar` — mejora el prompt y la KB desde conversaciones reales. *(Pro)*
- `/campana` — reactiva leads / manda seguimientos (respeta la ventana 24h de WhatsApp). *(Pro)*
- `/clonar` — arma la base de conocimiento desde el sitio web del negocio. *(Pro)*
- `/precios` — actualiza el menú / lista de precios y reindexa. *(Pro)*
- `/superpoderes` — enciende y configura los 12 superpoderes de Forja+ (Reportes, Multi-idioma,
  Encuestas, Recupera no-shows, Reseñas, Cobros…). Entrevista al usuario si el superpoder necesita
  datos suyos (Stripe, link de Google, plantilla de WhatsApp). Toggles en D1, sin redeploy. *(Pro)*
- `/conexiones-composio` — conecta el bot a CUALQUIER app externa vía Composio (Google
  Calendar, Gmail, Slack, Notion, CRMs…) sin código por app. Guarda `COMPOSIO_API_KEY` como
  secret. *(Pro)*
- `/voz-de-marca` — ajusta el tono del bot. `/auditoria`, `/autopsia`, `/cliente-misterioso`,
  `/agregar-tool` — mantenimiento técnico y pruebas.

**Modo Agencia (revender bots)** *(todas Pro)*
- `/demo` (bot de muestra para un prospecto), `/cliente-nuevo` — monta un bot para un cliente de reventa, de punta a punta.
- `/roi` — calcula el retorno de inversión para un prospecto (ahorro + ingreso recuperado, conservador) y lo entrega en un PDF con la marca del negocio. Munición para cerrar.
- `/cotizar` — arma el precio para un prospecto (sin socavar el piso de $2,000–3,000).
- `/propuesta` — documento comercial para cerrar la venta.
- `/cobrar` — organiza el cobro (link de pago / factura) con las herramientas del miembro.
